/* Header file which defines type of the subroutine subroutine_fnc */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int subroutine_fnc(int fd);
